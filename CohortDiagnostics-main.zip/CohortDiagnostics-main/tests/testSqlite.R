library(testthat)
options(dbms = "sqlite")
test_check("CohortDiagnostics")
